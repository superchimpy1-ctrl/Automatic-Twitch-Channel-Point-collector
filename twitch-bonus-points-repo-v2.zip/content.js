// Twitch Bonus Points Collector - content script
// Runs on twitch.tv pages. Watches for the channel points balance and the
// "claim bonus" button (which appears/disappears without a full page load),
// and auto-clicks it when auto-claim is enabled.

(function () {
  console.log("[Twitch Bonus Points] content script loaded on", location.href);

  const KEY_ENABLED = "autoClaimEnabled";
  const KEY_COUNT = "claimCount";
  const KEY_POINTS = "points";
  const KEY_LOG = "claimLog";

  let lastClaimAt = 0;
  const CLAIM_COOLDOWN_MS = 5000; // avoid double-clicking the same button

  function getPointsBalance() {
    const el = document.querySelector('[data-test-selector="balance-string"]');
    return el ? el.textContent.trim() : null;
  }

  // Twitch doesn't keep a stable class name on the claim button, but it does
  // set an aria-label containing "bonus" on it. Fall back to the older
  // test-selector class in case that changes back.
  function findClaimButton() {
    const byAria = document.querySelectorAll("button[aria-label]");
    for (const b of byAria) {
      if (/bonus/i.test(b.getAttribute("aria-label"))) return b;
    }
    const legacy = document.querySelector(".claimable-bonus__icon");
    if (legacy) return legacy.closest("button") || legacy;
    return null;
  }

  async function isEnabled() {
    const data = await browser.storage.local.get(KEY_ENABLED);
    return data[KEY_ENABLED] !== false; // default: enabled
  }

  async function recordClaim() {
    const data = await browser.storage.local.get([KEY_COUNT, KEY_LOG]);
    const count = (data[KEY_COUNT] || 0) + 1;
    const log = data[KEY_LOG] || [];
    log.unshift({
      time: Date.now(),
      channel: location.pathname.replace(/^\//, "") || "(unknown)",
    });
    await browser.storage.local.set({
      [KEY_COUNT]: count,
      [KEY_LOG]: log.slice(0, 50),
    });
  }

  async function updatePoints() {
    const points = getPointsBalance();
    if (points) {
      await browser.storage.local.set({ [KEY_POINTS]: points, updatedAt: Date.now() });
    }
  }

  async function tick() {
    updatePoints();

    if (!(await isEnabled())) return;

    const now = Date.now();
    if (now - lastClaimAt < CLAIM_COOLDOWN_MS) return;

    const btn = findClaimButton();
    if (btn) {
      btn.click();
      lastClaimAt = now;
      await recordClaim();
      setTimeout(updatePoints, 1500);
    }
  }

  const observer = new MutationObserver(() => {
    tick();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Fallback poll in case the bonus button appears without triggering a
  // mutation the observer catches (e.g. a class toggle deep in a subtree).
  setInterval(tick, 15000);

  tick();
})();
