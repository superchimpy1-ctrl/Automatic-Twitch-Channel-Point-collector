async function render() {
  const data = await browser.storage.local.get([
    "points",
    "claimCount",
    "autoClaimEnabled",
    "claimLog",
  ]);

  document.getElementById("points").textContent = data.points || "– (open a stream)";
  document.getElementById("count").textContent = data.claimCount || 0;
  document.getElementById("toggle").checked = data.autoClaimEnabled !== false;

  const log = data.claimLog || [];
  const ul = document.getElementById("log");
  ul.innerHTML = "";
  if (log.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No claims yet";
    ul.appendChild(li);
  } else {
    log.slice(0, 10).forEach((entry) => {
      const li = document.createElement("li");
      const d = new Date(entry.time);
      li.textContent = `${d.toLocaleTimeString()} — ${entry.channel}`;
      ul.appendChild(li);
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  render();
  document.getElementById("toggle").addEventListener("change", (e) => {
    browser.storage.local.set({ autoClaimEnabled: e.target.checked });
  });
});

setInterval(render, 3000);
